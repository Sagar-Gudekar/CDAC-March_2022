//11. Write a Java program to print the area and perimeter of a circle. 
//Test Data:
//Radius = 7.5
//Expected Output
//Perimeter is = 47.12388980384689
//Area is = 176.71458676442586


import java.util.Scanner;
class Circle

 { 
   public static void main (String[] args)
   {
   System.out.println("Enter radius of circle");
   Scanner sc=new Scanner(System.in);
   float radius=sc.nextFloat();
   
   float area=3.1416f*radius*radius;
   float perimeter=2*3.1416f*radius;
   
   
  System.out.println("Perimeter of circle is="+" "+perimeter);
  System.out.print("Area of circle is="+" "+area);

   }
  
 
}