//6. Write a Java program to print the sum (addition), multiply, subtract, divide and 
//remainder of two numbers. 
//Test Data:
//Input first number: 125
//Input second number: 24

import java.util.Scanner;

class Basic_Arithmetic
{
  public static void main(String [] args)
  
  {
	  Scanner sc=new Scanner(System.in);
    System.out.println("Enter the First no-125:");
	int a=sc.nextInt();
	System.out.println("Enter the Second no-24:");
    int b=sc.nextInt();
	
	System.out.println("Addition of given no is="+" "+(a+b));
	System.out.println("Multiplication of given no is="+" "+(a*b));
	System.out.println("Substraction of given no is="+" "+(a-b));
	System.out.print("Division of given no is="+" "+(a/b));

  }

}