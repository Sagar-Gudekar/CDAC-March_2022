
//15. Write a Java program to swap two variables. 


import java.util.Scanner;

 class swap_using3_variable {

	public static void main(String[] args) {
		
		int temp;
		System.out.println("Enter values of a and b is=");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		temp=a;
		a=b;
		b=temp;
		System.out.println("After swapping numbers will be="+" a="+a+" "+"b="+b);

	}

}
