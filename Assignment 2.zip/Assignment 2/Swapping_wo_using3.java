//4. Swap two numbers without using third variable approach. 


/*
STEP 1: START.
STEP 2: ENTER x, y.
STEP 3: PRINT x, y.
STEP 4: x = x + y.
STEP 5: y= x - y.
STEP 6: x =x - y.
STEP 7: PRINT x, y.
STEP 8: END
*/
import java.util.Scanner;
{
 class Swapping_wo_using3
  
 public static void main(String[] args)
 {
 System.out.println("Enter values before swapping");
 	Scanner sc=new Scanner(System.in);

   for(int num=1;num<=2;num++)
    {
	num=sc.nextInt();
	}
   System.out.println("Enter values after swapping"+num);

}
 }