//2. Write a Java program to print the sum of two numbers. 

class sum
 {
     public static void main(String[] args)

  {
    System.out.print("Addition of 74 + 36 is="+" " +(74+36));
  
  
  }




}
