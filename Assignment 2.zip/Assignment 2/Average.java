//12. Write a Java program that takes three numbers as input to calculate and print the 
//average of the numbers.


class Average

{
 public static void main(String[] args)
 
 
  {
  int a=10,b=20,c=40;
 int d=(a+b+c)/3;
  System.out.println("Average of given number is="+" "+d);
  
  }
 
}