//4. Write a Java program to print the result of the following operations. 
//Test Data: 
//a. -5 + 8 * 6
//b. (55+9) % 9
//c. 20 + -3*5 / 8
//d. 5 + 15 / 3 * 2 - 8 % 3
//Expected Output :
//43
//1
//19
//13

class Calculation
{


   public static void main(String [] args)
   {
    
    System.out.println("Evalution of (-5 + 8 * 6) is="+" "+(-5 + 8 * 6));
    System.out.println("Evalution of ((55+9) % 9) is="+" "+((55+9) % 9));
	System.out.println("Evalution of (20 + -3*5 / 8) is="+" "+(20 + -3*5 / 8));
	System.out.println("Evalution of (5 + 15 / 3 * 2 - 8 % 3) is="+" "+(5 + 15 / 3 * 2 - 8 % 3));
   }
}