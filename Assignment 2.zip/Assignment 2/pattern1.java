//8. Write a Java program to display the following pattern. 
//Sample Pattern :
/*
//Pattern 1=
   j
   j
j  j
 jj
*/
/*
 class pattern1
 
  {
  public static void main(String [] args)
    {
	System.out.println("   j");
    System.out.println("   j");
	System.out.println("j  j");
	System.out.println(" jj ");

	}
  
  }
 */ 
  
 /* 
  //Pattern 2=
  a
 a a
aaaaa
a   a
*/

/*
 class pattern1
 
  {
  public static void main(String [] args)
    {
	System.out.println("  a  ");
    System.out.println(" a a ");
	System.out.println("aaaaa");
	System.out.println("a   a");

	}
  
  }
  */
  
 /*  
  Pattern 3=
  v     v
   v   v
    v v
     v
	 */

 class pattern1
 
  {
  public static void main(String [] args)
    {
	System.out.println("v     v");
    System.out.println(" v   v");
	System.out.println("  v v");
	System.out.println("   v  ");

	}
  
  }
  