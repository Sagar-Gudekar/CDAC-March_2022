//7. Write a Java program that takes a number as input and prints its multiplication 
//table upto 10. 
//Test Data:
//Input a number: 8

import java.util.Scanner;

class Table_print

{

  public static void main(String [] args)
  
  {
  
    System.out.print("Enter any no to be print table:");
	Scanner sc=new Scanner(System.in);
	int num=sc.nextInt();
	for(int i=1;i<=10;i++)
	
	System.out.println(num +"*"+i+"="+" "+num*i);

	System.out.println();
  
  }
  

}