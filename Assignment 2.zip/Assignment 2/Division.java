//3. Write a Java program to divide two numbers and print on the screen. 
 
 class Division
 {
    public static void main(String [] args)
	
	{
	  System.out.println("Division is  50/3 is="+" "+( 50/3)); 

	}
 
  
 }