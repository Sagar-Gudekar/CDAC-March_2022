//19. To print the following series EVEN number Series 2 4 6 8 10 12 14 16 .....

public class Print_Even_Number {

	public static void main(String[] args) 
	{
		System.out.println("Even no from 1 to 100 is =");
		for(int i=2;i<=100;i+=2)
			
			System.out.println(i);
			

	}

}
