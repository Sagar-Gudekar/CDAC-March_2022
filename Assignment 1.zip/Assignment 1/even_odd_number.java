// 1. Check the given number is EVEN or ODD. 

import java.util.Scanner;

public class even_odd_number {

	public static void main(String[] args)
	{
	System.out.println("Enter no to be check odd or even");
	Scanner sc=new Scanner(System.in);
	int num=sc.nextInt();
	
	if(num%2==0)
	{
	System.out.println("Entered number is EVEN");
	}
	else
		System.out.println("Entered number is ODD");
		
	
		
	}

}

