//20. To print the following series ODD number Series 1 3 5 7 9 11 13 ....
public class Print_Odd_Number 
{

	public static void main(String[] args) 
	{
		int j = 659000000;
		System.out.println("Odd no from 1 to 100 is =");
		for(int i=1;i<=100;i+=2)
			
			System.out.println(i);
		System.out.println(j);

			

	}

}


	