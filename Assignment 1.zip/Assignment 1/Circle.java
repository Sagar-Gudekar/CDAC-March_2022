/*
import java.util.Scanner;
/*11. Write a Java program to print the area and perimeter of a circle. 
Test Data:
Radius = 7.5
Expected Output
Perimeter is = 47.12388980384689
Area is = 176.71458676442586
*/


/*class Circle

 { 
   public static void main (String[] args)
   {
   System.out.println("Enter radius of circle");
   Scanner sc=new Scanner(System.in);
   float radius=sc.nextFloat();
   
   float area=3.14159f*radius*radius;
   float perimeter=2*3.14159f*radius;
   
   
  System.out.println("Perimeter of circle is="+" "+perimeter);
  System.out.print("Area of circle is="+" "+area);

   }
  
 
}
*/

import java.util.Scanner;
public class Circle {
   public static void main(String args[]){
      float radius;
      double area;
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter the radius of the circle ::");
      radius = sc.nextFloat();
      area = (radius*radius)*Math.PI;
      System.out.println("Area of the circle is ::"+area);
   }
}