//11. Write a Java Program to find the smallest of 3 numbers (a,b,c) 

import java.util.Scanner;

public class smallest_Number {

	public static void main(String[] args) {
		
		System.out.println("Enter your 3 numbers is =");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();

		if(a<b && a<c)
			System.out.println("smallest  no is "+a);
	
		
		else if(b<c && b<a)
			System.out.println("smallest no is "+b);
		else
			System.out.println("smallest no is "+c);
		
	}

}

//11.1 Write a Java Program to find greater of 3 numbers (a,b,c) 

/*
public class smallest_Number {

	public static void main(String[] args) {
		
		System.out.println("Enter your numbers is =");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();

		if(a>b && a>c)
			System.out.println("greater no is "+a);
	
		
		else if(b>c && b>a)
			System.out.println("greater no is "+b);
		else
			System.out.println("greater no is "+c);
		
	}

}*/


