import java.util.Scanner;
/*
public class Reverse_number {

	public static void main(String[] args)
	{
			Scanner sc=new Scanner(System.in);
				int num,n,i=0;
				System.out.println("Enter four digit number is =");
				num=sc.nextInt();
				n=num;
				for(i=0;i<4;i++)
				{
					num=n%10;
				    System.out.println(num);
					num=n/10;
					n=num;
				}
			}

}
*/
public class Reverse_number {

	public static void main(String[] args) 
	{
		int n=1;
		System.out.println("Enter your number is =");
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
	
		int a=num/1000;
		int b=(num%1000)/100;
		int c=(num%100)/10;
		int d=(num%10);
		  
        System.out.println("digits of given is is=");
        System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		
		System.out.println("Reverse no of "+num +" is= "+d+c+b+a);
	}

}
