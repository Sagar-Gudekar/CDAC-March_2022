import java.util.Scanner;

//8. Write a Java Program to print the digits of a Given Number. 
/*

public class PrintDigit
{

	public static void main(String[] args)
	{
		System.out.println("Enter four digit number is =");
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		
		int a=num/1000;
		int b=(num/100)%10;
		int c=(num/10)%10;
		int d=((num%1000)%100)%10;
		
		int a=num/1000;
		int b=(num%1000)/100;
		int c=(num%100)/10;
		int d=(num%10);

		System.out.println("Digits of given number is=");

		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		}
}
*/
