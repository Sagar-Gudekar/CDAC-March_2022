//4. Swap two numbers without using third variable approach. 


/*
STEP 1: START.
STEP 2: ENTER x, y.
STEP 3: PRINT x, y.
STEP 4: x = x + y.
STEP 5: y= x - y.
STEP 6: x =x - y.
STEP 7: PRINT x, y.
STEP 8: END
*/
import java.util.Scanner;

 public class Swapping_wo_using3
 {
  
 public static void main(String[] args)
 {
  
	 System.out.print("Enter values :");
 	Scanner sc=new Scanner(System.in);
   int x=sc.nextInt();
   int y=sc.nextInt();
   System.out.println("before swapping values are :"+"x"+"="+x+" " +"y"+"="+y);

    x=x+y;
    y=x-y;
    x=x-y;

    System.out.println("After swapping values are :"+"x"+"="+x+" " +"y"+"="+y);

     }
 
 }
 