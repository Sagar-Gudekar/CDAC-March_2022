//2. Write a Java Program to find the Factorial of given number. 


import java.util.Scanner;

public class factorial {

	public static void main(String[] args)
	{    
		int i, fact=1;
		System.out.println("Enter your number");
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		
		for(i=1;i<=num;i++)
			
		fact=fact*i;
		System.out.println(fact);


	}

}
