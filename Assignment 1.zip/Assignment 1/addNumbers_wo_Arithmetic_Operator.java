
//12. How to add two numbers without using the arithmetic operators in Java? 

import java.util.Scanner;

public class addNumbers_wo_Arithmetic_Operator {

	public static void main(String[] args)
	{
		System.out.println("Enter values of a and b is=");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		a+=b;
		System.out.println("addition od a & b is="+a);
		

	}

}
