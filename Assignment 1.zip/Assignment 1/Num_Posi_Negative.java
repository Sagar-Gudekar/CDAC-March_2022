//5. How to check the given number is Positive or Negative in Java? 


import java.util.Scanner;

public class Num_Posi_Negative {

	public static void main(String[] args) 
	{
		System.out.println("Enter your number and check + or - =");
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		if(num>0 )
			System.out.println("Entered number is possitive");
		else
			
	        if(num==0)
			System.out.println("Entered number is zero");
	        else
	        	System.out.println("Entered numebr  is negative");

	}

}
