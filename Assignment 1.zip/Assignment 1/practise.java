
public class practise {

	public static void main(String[] args) {
		System.out.println("good morning..");
   
	practise1 p1=new practise1();	
	//	System.out.println(p1);
		
	}

}

class practise1 {

 {
		System.out.println("good morning..............");

	}

}
