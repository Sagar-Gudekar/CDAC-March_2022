//4. Swap two numbers without using third variable approach. 


import java.util.Scanner;

public class swapping {

	public static void main(String[] args) {
		
		int temp;
		System.out.println("Enter values of a and b is=");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		temp=a;
		a=b;
		b=temp;
		System.out.println("After swapping numbers will be="+" a="+a+" "+"b="+b);

	}

}
