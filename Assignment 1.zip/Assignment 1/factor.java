
//9. Write a Java Program to print all the Factors of the Given number. 

import java.util.Scanner;

public class factor {

	public static void main(String[] args)
	{
		int n=1;
		System.out.println("Enter your number is =");
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		System.out.println("factors of given no is");

		while(n<=num)
		{
			if(num%n==0)
				
			System.out.println(n);
			n++;
		}
		
	}

}
