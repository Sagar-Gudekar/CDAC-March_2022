//Write a Java Program to find sum of the digits of a given number. //798

import java.util.Scanner;
public class Sum_of_digit {

	public static void main(String[] args) 
	{
		int n=1;
		System.out.println("Enter your number is =");
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
	
		int a=num/1000;
		int b=(num%1000)/100;
		int c=(num%100)/10;
		int d=(num%10);
		  
        System.out.println("digits of given is is=");
        System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		
		System.out.println("sum of enter digit is="+(a+b+c+d));
	}

}
