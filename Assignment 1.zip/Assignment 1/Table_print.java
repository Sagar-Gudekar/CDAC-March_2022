
import java.util.Scanner;

class Table_print

{

  public static void main(String [] args)
  
  {
  int a = 0;
    System.out.println("Enter any no to be print table:");
	Scanner sc=new Scanner(System.in);
	int num=sc.nextInt();
	for(int i=1;i<=10;i++)
	//a=num*i;
	
	System.out.println(num +"*"+i+"="+" "+num*i);
	System.out.println();
  
  }
  

}

