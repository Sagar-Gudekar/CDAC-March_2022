/*
1 2 3 4 5 
  1 2 3 4 
    1 2 3 
      1 2 
        1 
*/
/*
class start_pattern1
{
	public static void main(String args [])
	{	
		int k=0;
		for(int i=5;i>=1;i--)//Row
		{
			for(int l=1;l<=k;l++)//Column 
			{
				System.out.print("  ");
			
			}
			//int sum = 0;
			for( int j=1;j<=i;j++)//Column
			{
			//	sum+=j;//sum=sum+j
				System.out.print(j+" ");
			}
		//	System.out.print(" "+sum);
			//sum=0;
			k++;
			System.out.println();
		}
		
	}
}
*/


 class star_pattern
{
    public static void main(String[] args) 
    {
    
         
        for (int i = 1; i <= 5; i++) 
        {
            for (int j = i; j >= 1; j--)
            {
                System.out.print(j+" ");
            }
             
            System.out.println();
        }
         
      
    }
}
