          /*
      5 
    5 4 
   5 4 3 
  5 4 3 2 
 5 4 3 2 1 

 */
/*
class P8
{ 
 public static void main(String[] args)
 {

  for( int i=5;i>=1;i--)
  {
   for(int k=i;k>=1;k--)
   {
    System.out.print(" ");
   }
   
   for(int j=5;j>=i;j--)
   {
    System.out.print(j+" ");
    }

  System.out.println();

  }
  

 }
}
*/



class P8
{ 
 public static void main(String[] args)
 {
  int i,j,k,rows=5,l=5;
  for(  i=1;i<=rows;i++)
  {
   for( k=4;k>=i;k--)
   {
    System.out.print(" ");
   }
      l--; 
   for( j=1;j<=i;j++)
   {      
    System.out.print((l+j)+" ");
    }

  System.out.println();

  }
  

 }
}


