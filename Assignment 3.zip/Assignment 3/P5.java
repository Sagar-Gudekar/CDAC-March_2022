/*
A
BB
CCC
DDDD
EEEEE
*/

class P5
{ 
 public static void main(String[] args)
 {
   char i=65,j=65;
  for(i=65;i<=69;i++)
  {
   for(j=65;j<=i;j++)
   {
    System.out.print(i);
   }
  
  System.out.println();
  }
 }
}