/*
    A 
   A B 
  A B C 
 A B C D 
A B C D E 
 

 */
class P9
{ 
 public static void main(String[] args)
 {
	int count=4; 
  for( char i=65;i<=69;i++)
  {
   for( int k=count;k>=1;k--)
   {
    System.out.print(" ");
   }
   
   for(char j=65;j<=i;j++)
   {
    System.out.print(j+" ");
   }
   
   System.out.println();
   count--;
   
  }
 }
}



