


/*
 * * * * * * * * * 
  * * * * * * * 
    * * * * * 
      * * * 
        * 
*/

class P7_1
{ 
 public static void main(String[] args)
	 {
	  int i,j,k,rows=5,l=1;
	      for( i=1;i<=rows;i++)
	     {
	        for( k=4;k>=i;k--)
	       {
	        System.out.print("  ");
	       }
	   
	        for( j=1;j<=l;j++)
	      {      
	      System.out.print('*'+" ");
	      }
	          l+=2;

	     System.out.println();
	     }
    l=7;rows=4;
      for( i=1;i<=rows;i++)
     {
        for( k=1;k<=i;k++)
       {
        System.out.print("  ");
       }

        for( j=l;j>=i;j--)
     {      
      System.out.print('*'+" ");

      }
    l-=1;
    
     System.out.println();
    }
  }
}
