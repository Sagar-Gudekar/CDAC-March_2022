/*
5
45
345
2345
12345

*/

/*
1
23
345
4567
56789


class P25
{ 
 public static void main(String[] args)
 {
	int k=0; 
  for( int i=1;i<=5;i++)
  {
	  
  
   for(int j=1;j<=i;j++)
   {
  System.out.print(j+k);
  
   }
  k++;
  System.out.println();
  }
 }
}

*/

/*
1 
2 1 
3 2 1 
4 3 2 1 
5 4 3 2 1 


public class P25
{
    public static void main(String[] args) 
    {
    
         
        for (int i = 1; i <= 5; i++) 
        {
            for (int j = i; j >= 1; j--)
            {
                System.out.print(j+" ");
            }
             
            System.out.println();
        }
         
      
    }
}

*/