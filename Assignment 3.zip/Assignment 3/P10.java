/*
    E 
   D E 
  C D E 
 B C D E 
A B C D E 

*/

class P10
{ 
 public static void main(String[] args)
 {
	 int l=5;
  for(int i=1;i<=5;i++)
  {
   for(int k=4;k>=i;k--)
   {
    System.out.print(" ");
   }
     l--;
   for(int j=1;j<=i;j++)
   {
    System.out.print((char) (j+l+64)+" ");
   }
   
  System.out.println();
  }
 }
}



/*

    E 
   E D 
  E D C 
 E D C B 
E D C B A 


class P10
{ 
 public static void main(String[] args)
 {
	 int count=4;
  for( char i=69;i>=65;i--)
  {
   for(int k=count;k>=1;k--)
   {
    System.out.print(" ");
   }
   
   for(char j=69;j>=i;j--)
   {
    System.out.print(j+" ");
   }
   count--;
  System.out.println();
  }
 }
}

*/

