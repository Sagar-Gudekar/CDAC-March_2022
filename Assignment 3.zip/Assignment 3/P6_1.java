


/*
 * * * * * * * * * 
  * * * * * * * 
    * * * * * 
      * * * 
        * 
*/

class P6_1
{ 
 public static void main(String[] args)
 {
  int i,j,k,rows=5,l=8;
      for( i=0;i<=rows;i++)
     {
        for( k=1;k<=i;k++)
       {
        System.out.print("  ");
       }

        for( j=l;j>=i;j--)
     {      
      System.out.print('*'+" ");

      }
    l-=1;
    
     System.out.println();
    }
  }
}
