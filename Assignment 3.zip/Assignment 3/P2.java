/*
A
AB
ABC
ABCD
ABCDE
*/
/*
class P2
{ 
 public static void main(String[] args)
 {
	 char i=65,j=65;
  for( i=65;i<=69;i++)
  {
   for( j=65;j<=i;j++)
   {
  System.out.print(j);
  
   }
  
  System.out.println();
  }
 }
}
*/



/*
class P2
{ 
 public static void main(String[] args)
 {
	// char i=65,j=65;
  for( int i=1;i<=5;i++)
  {
   for( int j=1;j<=i;j++)
   {
	  
  System.out.print((char )(j+64));
  
   }
  
  System.out.println();
  }
 }
}
*/